package com.mycompany.quickchatapp;

import java.util.Scanner;

public class QuickChatApp {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login login = new Login();

        String firstName;
        String lastName;
        String username;
        String password;
        String cellphoneNum;
        String registrationMessage;
        boolean isLoggedIn;

        System.out.print("Please enter your first name: ");
        firstName = input.nextLine();

        System.out.print("Please enter your last name: ");
        lastName = input.nextLine();

        System.out.print("Please enter your username: ");
        username = input.nextLine();

        if (login.checkUserName(username)) {
            System.out.println("Username successfully captured.");
        } else {
            System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
        }

        System.out.print("Please enter your password: ");
        password = input.nextLine();

        if (login.checkPasswordComplexity(password)) {
            System.out.println("Password successfully captured.");
        } else {
            System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
        }

        System.out.print("Please enter your cellphone number: ");
        cellphoneNum = input.nextLine();

        if (login.checkCellPhoneNumber(cellphoneNum)) {
            System.out.println("Cell phone number successfully added.");
        } else {
            System.out.println("Cell phone number incorrectly formatted or does not contain an international code; please correct the number and try again.");
        }

        registrationMessage = login.registerUser(firstName, lastName, username, password, cellphoneNum);
        System.out.println(registrationMessage);

        if (registrationMessage.equals("User has been registered successfully.")) {
            System.out.println("\nLogin using the same username and password.");

            System.out.print("Enter login username: ");
            String loginUsername = input.nextLine();

            System.out.print("Enter login password: ");
            String loginPassword = input.nextLine();

            isLoggedIn = login.loginUser(loginUsername, loginPassword);
            System.out.println("Login successful: " + isLoggedIn);
            System.out.println(login.returnLoginStatus(loginUsername, loginPassword));
        }

        input.close();
    }
}
