QuickChatApp NetBeans files

Files included:
- src/com/mycompany/quickchatapp/Login.java
- src/com/mycompany/quickchatapp/QuickChatApp.java
- test/com/mycompany/quickchatapp/LoginTest.java

How to use in NetBeans:
1. Create a Java project named QuickChatApp or PROG5121POE.
2. Create the package: com.mycompany.quickchatapp
3. Paste Login.java and QuickChatApp.java into Source Packages.
4. Paste LoginTest.java into Test Packages.
5. Add JUnit 4 if NetBeans asks for it.
6. Run QuickChatApp.java to test the program.
7. Run LoginTest.java or Test Project to run the unit tests.
