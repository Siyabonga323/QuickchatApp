package com.mycompany.quickchatapp;

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    private final Login login = new Login();

    @Test
    public void testLoginSuccessful() {
        login.registerUser("Kyle", "Smith", "kyl_1", "Ch&sec@ke99!", "+27838968976");
        assertTrue(login.loginUser("kyl_1", "Ch&sec@ke99!"));
    }

    @Test
    public void testLoginFailed() {
        login.registerUser("Kyle", "Smith", "kyl_1", "Ch&sec@ke99!", "+27838968976");
        assertFalse(login.loginUser("kyl_1", "wrongPass1!"));
    }

    @Test
    public void testUsernameCorrectlyFormatted() {
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        assertFalse(login.checkUserName("kyle!!!!!!"));
    }

    @Test
    public void testPasswordMeetsComplexityRequirements() {
        assertTrue(login.checkPasswordComplexity("Ch&sec@ke99!"));
    }

    @Test
    public void testPasswordDoesNotMeetComplexityRequirements() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCellPhoneNumberCorrectlyFormatted() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testCellPhoneNumberIncorrectlyFormatted() {
        assertFalse(login.checkCellPhoneNumber("08966553"));
    }

    @Test
    public void testReturnLoginStatusSuccess() {
        login.registerUser("Kyle", "Smith", "kyl_1", "Ch&sec@ke99!", "+27838968976");
        assertEquals("Welcome Kyle, Smith it is great to see you.", login.returnLoginStatus("kyl_1", "Ch&sec@ke99!"));
    }

    @Test
    public void testReturnLoginStatusFailure() {
        login.registerUser("Kyle", "Smith", "kyl_1", "Ch&sec@ke99!", "+27838968976");
        assertEquals("Username or password incorrect, please try again.", login.returnLoginStatus("wrong", "wrong"));
    }
}
